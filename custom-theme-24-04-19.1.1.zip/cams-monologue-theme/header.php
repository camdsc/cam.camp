<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<div id="page" class="site">
    <header id="masthead" class="site-header">
        <div class="title-container">
            <h1 class="monologue">cam's monologue</h1>
            <div class="snowflake" id="snowflake">❄</div>
        </div>

        <nav id="menu" class="main-navigation">
            <div class="menu-container">
                <div class="menu-row first-row">
                    <div class="left-column">
                        <?php
                        wp_nav_menu(array(
                            'theme_location' => 'primary',
                            'menu_id' => 'primary-menu',
                            'container' => false,
                            'depth' => 1
                        ));
                        ?>
                    </div>
                    <div class="right-column">
                        <?php
                        wp_nav_menu(array(
                            'theme_location' => 'secondary',
                            'menu_id' => 'secondary-menu',
                            'container' => false,
                            'depth' => 1
                        ));
                        ?>
                    </div>
                </div>
                <?php if (is_front_page()): ?>
                <div class="menu-row second-row">
                    <div class="left-column">
                        <?php
                        wp_nav_menu(array(
                            'theme_location' => 'primary',
                            'menu_id' => 'primary-menu-expanded',
                            'container' => false,
                            'depth' => 1
                        ));
                        ?>
                    </div>
                    <div class="right-column">
                        <?php
                        wp_nav_menu(array(
                            'theme_location' => 'secondary',
                            'menu_id' => 'secondary-menu-expanded',
                            'container' => false,
                            'depth' => 1
                        ));
                        ?>
                    </div>
                </div>
                <?php endif; ?>
            </div>
        </nav>
    </header>

    <div id="content" class="site-content"> 