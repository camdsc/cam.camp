document.addEventListener('DOMContentLoaded', function() {
    const header = document.getElementById('masthead');
    const snowflake = document.getElementById('snowflake');
    const firstRow = document.querySelector('.menu-row.first-row');
    const secondRow = document.querySelector('.menu-row.second-row');
    let lastScrollTop = 0;
    let snowflakePosition = 0;

    // Calculate initial snowflake position
    function calculateSnowflakePosition() {
        const titleRect = document.querySelector('.title-container').getBoundingClientRect();
        const firstRowRect = firstRow.getBoundingClientRect();
        snowflakePosition = firstRowRect.top - titleRect.top;
    }

    // Handle scroll
    function handleScroll() {
        const scrollTop = window.pageYOffset || document.documentElement.scrollTop;
        const titleRect = document.querySelector('.title-container').getBoundingClientRect();
        const firstRowRect = firstRow.getBoundingClientRect();

        if (scrollTop > snowflakePosition) {
            header.classList.add('header-fixed');
        } else {
            header.classList.remove('header-fixed');
        }

        lastScrollTop = scrollTop;
    }

    // Handle snowflake click
    function handleSnowflakeClick() {
        const isExpanded = header.classList.contains('expanded');
        
        if (isExpanded) {
            header.classList.remove('expanded');
            if (secondRow) {
                secondRow.style.display = 'none';
            }
        } else {
            header.classList.add('expanded');
            if (secondRow) {
                secondRow.style.display = 'flex';
            }
        }
    }

    // Initialize
    calculateSnowflakePosition();
    window.addEventListener('resize', calculateSnowflakePosition);
    window.addEventListener('scroll', handleScroll);
    snowflake.addEventListener('click', handleSnowflakeClick);

    // Hide second row initially if not on homepage
    if (!document.body.classList.contains('home') && secondRow) {
        secondRow.style.display = 'none';
    }
}); 