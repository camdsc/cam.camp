<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<div id="page" class="site">
    <header id="masthead" class="site-header">
        <!-- Centered Title with Snowflake -->
        <div class="title-container">
            <h1 class="monologue"><?php bloginfo('name'); ?></h1>
            <span class="snowflake">❄️</span>
        </div>

        <!-- Menu: LOCATE and EXAMINE -->
        <div id="menu">
            <?php
            wp_nav_menu(array(
                'theme_location' => 'primary',
                'container'      => false,
                'menu_class'     => 'menu-items',
                'fallback_cb'    => false,
            ));
            ?>
        </div>
    </header>

    <div id="content" class="site-content"> 